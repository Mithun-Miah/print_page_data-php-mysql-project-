<?php
// IMAGE UPLOAD PHP MySQL START CODE HERE
$connect = mysqli_connect('localhost', 'root', '', 'image');
// if($connect){
//     echo "DB Conn Successful";
// }else{
//     echo "DB Conn Failed";
// }

if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $image_name = $_FILES['image']['name'];
    $tmp_name = $_FILES['image']['tmp_name'];
    
    $file_ext = explode(".", $image_name); // find only file extension name

    $file_check = strtolower(end($file_ext)); // cut only file extension name

    $valid_ext_name = array('png','jpg','jpeg'); // only allow those file extension name

    if(in_array($file_check, $valid_ext_name)){
        // check file size
        if($_FILES['image']['size'] < 2097152){ // 2 mb size allow
            // if file/image extension are correct then insert data permission here

            // Image Folder Location set code
        $upload = move_uploaded_file($tmp_name, "image_folder/".$image_name);

        if($upload){
            $insert = "INSERT INTO img_upload(name, phone, image)
            VALUES('$name', '$phone', '$image_name')";
            $query = mysqli_query($connect, $insert);
            if($query){
                echo "<script>alert('Data Send Success')</script>";
                // echo "Data Send Success";
            }else{
                echo "Data Send Failed";
            }
            
        }else{
            echo "Image Upload Failed";
        }

            
        }else{
            echo "<script>alert('check file size ! Only allow 2mb')</script>";

        }

    }else{
        echo "<script>alert('check file name ! Only allow png, jpg, jpeg file')</script>";
    }

}
// IMAGE UPLOAD PHP MySQL END CODE HERE
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <title>Image Upload CRUD Operations Project</title>
    <link rel="stylesheet" href="image_insert.css">
</head>

<body>
    <h2 class="title">Image Upload And Insert Data and Fetch Data / Read Data</h2>
    <div class="container" style="width:900px;">
        <form action="" enctype="multipart/form-data" method="POST">
            <input type="text" name="name" placeholder="Name"> <br><br>
            <input type="text" name="phone" placeholder="Phone"> <br><br>
            <input type="file" name="image"> <br><br>
            <button name="submit">Submit</button>
        </form>
        <hr>

        <!-- search code start here -->
        <form action="" method="POST">
            <input name="search_name" type="text" placeholder="enter search name" style="width:60%;">
            <button name="search_btn"
                style="width:20%; padding: 5px; font-size: 1.2rem;cursor: pointer;">Search</button>
        </form>
        <!-- search code end here -->

        <h1>Fetch Data / Read Data</h1>

        <form action="delete.php" method="POST">
            <table>
                <th>Id</th>
                <th>Name</th>
                <th>Phone</th>
                <th>Image</th>
                <th>Edit</th>
                <th>Delete</th>
                <th>Show Reports</th>
                <th>Status</th>
                <th>
                    <button name="del_btn" style="width:100%; font-size:14px; font-weight:600;">M-Delete</button>
                </th>

                <tbody>

                    <?php
                $search_input = ""; //declear blank variable for remove error
                // Search php code start here
                if(isset($_POST['search_btn'])){
                    $search_input = $_POST['search_name'];

                }
                
                //$select = "SELECT * FROM img_upload WHERE name LIKE '%$search_input%' "; // Only Search Query Code
                //$select = "SELECT * FROM img_upload WHERE name LIKE '%$search_input%' ORDER BY Id asc "; // Search and serial Number Acending Query Code
                $select = "SELECT * FROM img_upload WHERE name LIKE '%$search_input%' OR phone LIKE '%$search_input%' ORDER BY Id desc "; // Search and serial Number Decending Query Code
                $query = mysqli_query($connect, $select);

                $i = 1;
                while($row = mysqli_fetch_array($query)){ ?>

                    <!-- while loop body -->

                    <tr>
                        <td><?php echo $i ?></td>
                        <td><?php echo $row['name'] ?></td>
                        <td><?php echo $row['phone'] ?></td>
                        <td><img src="image_folder/<?php echo $row['image'] ?>" height="100" width="100" alt=""></td>
                        <td><a href="edit.php?idNo=<?php echo $row['Id']; ?>">edit</a></td>
                        <td><a onclick="return confirm('Do You Want To Delete !')"
                                href="delete.php?idNo=<?php echo $row['Id']; ?>&image_pic=<?php echo $row['image']?>">delete</a>
                        </td>
                        <td><a href="show.php?idNo=<?php echo $row['Id']; ?>">Show Reports</a></td>
                        <!-- button enable and disable code start here -->
                        <td>
                            <?php
                            if($row['status'] == 1){
                                echo "<a href='status.php?id=$row[Id]&&status=0'>
                                <button style='background:blue; font-size:14px; padding:10px; width:100%;'>enable</button></a>";
                            }else{
                                echo "<a href='status.php?id=$row[Id]&&status=1'>
                                <button style='background:red; font-size:14px; padding:10px; width:100%;'>disable</button></a>";
                                
                            }
                        ?>
                        </td>
                        <!-- button enable and disable code end here -->
                        <td>
                            <input type="checkbox" name="Multiple_id[]" value="<?php echo $row['Id'] ?>">
                        </td>

                    </tr>

                    <?php 
                $i++;

                }

                ?>
                </tbody>
            </table>

        </form>

    </div>


</body>

</html>