<?php

$connect = mysqli_connect('localhost', 'root', '', 'image');

$id = $_GET['id'];
$status = $_GET['status']; // 0 recieve

$update = "UPDATE img_upload SET status = $status WHERE Id = $id";
$query = mysqli_query($connect, $update);
header('location:image_insert.php');



?>