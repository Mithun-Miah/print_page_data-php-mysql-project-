<?php
// // explode() method practice
// $text = "hello world. , I am mithun";
// print_r (explode(".", $text));

// // strtolower() method practice
// $text_lowercase = "MY NAME IS MITHUN MIAH";
// echo (strtolower($text_lowercase));

// in_array() method practice
// $name = array('fiz', 'shakib', 'tamim', 'mithun');
// if(in_array("fiz",$name)){
//     echo "name is match";
// }else{
//     echo "name does not match";
// }

// // end() method practice
// $name = array('fiz', 'shakib', 'tamim', 'mithun', 'milon');
// echo end($name);



?>