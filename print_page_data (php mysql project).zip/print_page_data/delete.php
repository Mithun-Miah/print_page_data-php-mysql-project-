<?php

    // Database Connection with mysql database
    $connect = mysqli_connect("localhost", "root", "", "image");

    if(isset($_POST['del_btn'])){
        $Multiple_id = $_POST['Multiple_id'];
        $extract = implode(",", $Multiple_id);

        $delete = "DELETE FROM img_upload WHERE Id IN($extract)"; // Select multiple data for delete query code
        $query = mysqli_query($connect, $delete);
        //header("location:image_insert.php");
        if($query){
            echo "<script>alert('Data Delete Done')</script>";
                header("location:image_insert.php");
            } else{
                echo "<script>alert('Data Delete Fail')</script>";
                header("location:image_insert.php");
            }
    }


    // // Delete Single Data Code Start Here
    // $id = $_GET['idNo'];
    // $image = $_GET['image_pic'];

    // //For Show Data in Delete page input field
    // $delete = "DELETE FROM img_upload WHERE Id = $id";
    // $query = mysqli_query($connect, $delete);
    
    // if($query){
    //     unlink("image_folder/$image"); // Image Folder and Image pic location for Delete code method
    //     header("location:image_insert.php");
    // } else{
    //     echo "<script>alert('Data Delete Fail')</script>";
    // }
    // // Delete Single Data Code End Here

?>