<?php
$connect = mysqli_connect('localhost', 'root', '', 'image');

$id = $_GET['idNo']; // Select with database id number

$select = "SELECT * FROM img_upload WHERE Id = $id";
$query = mysqli_query($connect, $select);
$row = mysqli_fetch_array($query);




?>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Report Page</title>
    <link rel="stylesheet" href="show.css">

</head>

<body>
    <div class="container">
        <a href="image_insert.php">Back Home</a>
        <h1>Reports Show</h1>
        <table>
            <th>Id</th>
            <th>Name</th>
            <th>Phone</th>
            <th>Image</th>
            <th>Print Reports</th>
        </table>
        <tbody style="border:1px solid black;">
            <td style="border:1px solid black;"><?php echo $row['Id'] ?></td>
            <td style="border:1px solid black;"><?php echo $row['name'] ?></td>
            <td style="border:1px solid black;"><?php echo $row['phone'] ?></td>
            <td style="border:1px solid black;"><img src="image_folder/<?php echo $row['image'] ?>" height="100"
                    width="100" alt=""></td>
            <td style="border:1px solid black;"><button onclick="window.print()" style="width:20%;">Print</button></td>
        </tbody>
    </div>

</body>

</html>